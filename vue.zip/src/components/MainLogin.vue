<script setup>
import { FwbButton } from "flowbite-vue";
import router from "@/router";
import {reactive, ref} from "vue";

const loginInput = ref({
  email: String,
  password: String
})


</script>

<template>
  <main class="fixed h-full w-full flex bg-gray-50 dark:bg-gray-900">
    <div class="grid max-w-screen-xl mx-auto lg:gap-20 lg:grid-cols-12">
      <!-- 로그인 -->
      <section
        class="w-full place-self-center lg:col-span-6 p-6 mx-auto bg-white rounded-lg shadow dark:bg-gray-800
      sm:max-w-xl sm:p-8"
      >
        <div class="flex items-center mb-6">
          <img
            src="@/assets/mi-symbol.svg"
            alt="kafp-mi-symbol"
            class="w-16 mr-2"
          >
          <img
            src="@/assets/mi-text.jpg"
            alt="kafp-mi-text"
            class="w-40 mt-3"
          >
        </div>
        <div class="font-extrabold text-2xl mb-4">
          출입통제체계
        </div>
        <p class="text-sm font-light text-gray-500 dark:text-gray-300">
          계정이 없으신가요? 
          <router-link
            to="#"
            class="font-medium text-primary-600 hover:underline dark:text-primary-500"
          >
            회원가입
          </router-link>
        </p>
        <section
          class="mt-4 space-y-6 sm:mt-6"
        >
          <div class="flex flex-col gap-6">
            <div>
              <label
                class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
              >아이디</label>
              <input
                v-model="email"
                type="text"
                class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600
                focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600
                dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                placeholder="ID"
                required=""
              >
            </div>
            <div>
              <label
                class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
              >비밀번호</label>
              <input
                v-model="password"
                type="password"
                placeholder="PASSWORD"
                class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600
                focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600
                dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                required=""
              >
            </div>
          </div>
          <div class="flex items-center">
            <div class="w-full h-0.5 bg-gray-200 dark:bg-gray-700" />
            <div class="w-32 px-5 text-center text-gray-500 dark:text-gray-400">
              또는
            </div>
            <div class="w-full h-0.5 bg-gray-200 dark:bg-gray-700" />
          </div>
          <a
            href="#"
            class="w-full inline-flex items-center justify-center py-2.5 px-5 mr-2 mb-2 text-sm font-medium
            text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100
            hover:text-gray-900 focus:z-10 focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-700 dark:bg-gray-800
            dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700"
          >
            SSO 로그인
          </a>
          <div class="flex items-center justify-between">
            <div class="flex items-start">
              <div class="flex items-center h-5">
                <input
                  id="remember"
                  aria-describedby="remember"
                  type="checkbox"
                  class="w-4 h-4 border border-gray-300 rounded bg-gray-50 focus:ring-3 focus:ring-primary-300
                  dark:bg-gray-700 dark:border-gray-600 dark:focus:ring-primary-600 dark:ring-offset-gray-800"
                >
              </div>
              <div class="ml-3 text-sm">
                <label
                  for="remember"
                  class="text-gray-500 dark:text-gray-300"
                >로그인 정보 기억</label>
              </div>
            </div>
            <a
              href="#"
              class="text-sm font-medium text-primary-600 hover:underline dark:text-primary-500"
            >비밀번호를 잊으셨나요?
            </a>
          </div>
          <fwb-button
            class="w-full text-white bg-primary-600 hover:bg-primary-700 focus:ring-4 focus:outline-none
            focus:ring-primary-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-primary-600
            dark:hover:bg-primary-700 dark:focus:ring-primary-800"
            @click=" login "
          >
            <span class="font-bold">로그인</span>
          </fwb-button>
        </section>
      </section>

      <!-- 공지사항 -->
      <section class="hidden w-full place-self-center lg:block lg:col-span-6 p-6 mx-auto bg-white rounded-lg shadow dark:bg-gray-800 sm:max-w-xl sm:p-2">
        <h1 class="font-extrabold border-b text-3xl pb-1">
          공지사항
        </h1>
        <ul class="px-0.5">
          <li>공지1</li>
          <li>공지2</li>
          <li>공지3</li>
          <li>공지4</li>
          <li>공지5</li>
        </ul>
      </section>
    </div>
  </main>
</template>

<script>
import axios from "axios"
export default {
  methods : {
    login() {
      let data = JSON.stringify({
        "email": this.email,
        "password": this.password
      });
      
      let config = {
        method: 'post',
        maxBodyLength: Infinity,
        url: 'http://localhost:8080/login',
        headers: { 
          'Content-Type': 'application/json'
        },
        data : data
      };

      axios.request(config)
      .then((response) => {
        const status = response.data.status;

        if(status) {
          router.push("/dashboard");
        }
        else {
          alert(response.data.error);
        }
      })
      .catch((error) => {
        console.log(error);
      });
    }
  }
}

</script>

<style scoped>
</style>
