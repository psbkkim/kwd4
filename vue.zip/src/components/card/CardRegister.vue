<script setup>

</script>

<template>
  <section class="dark:bg-gray-900">
    <div class="py-8 px-4 max-w-5xl md:ml-64 lg:mx-auto lg:py-16 lg:px-0">
      <div>
        <div
          id="create-product-accordion-collapse"
          class="xl:border xl:rounded-lg xl:border-gray-200 dark:border-gray-700"
          data-accordion="collapse"
        >
          <h3 id="create-product-accordion-collapse-heading-1">
            <button
              type="button"
              class="flex justify-between border-b items-center py-4 px-4 rounded-t-lg w-full font-medium leading-none text-left text-gray-900 bg-gray-50 sm:px-5 focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-800 dark:border-gray-700 dark:text-white hover:bg-gray-100 dark:bg-gray-700 dark:hover:bg-gray-600"
              data-accordion-target="#create-product-accordion-collapse-body-1"
              aria-expanded="true"
              aria-controls="create-product-accordion-collapse-body-1"
            >
              <span class="font-bold">카드 정보</span>
              <svg
                data-accordion-icon=""
                class="w-6 h-6 rotate-180 shrink-0"
                fill="currentColor"
                viewBox="0 0 20 20"
                xmlns="http://www.w3.org/2000/svg"
              ><path
                fill-rule="evenodd"
                d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                clip-rule="evenodd"
              /></svg>
            </button>
          </h3>
          <div
            id="create-product-accordion-collapse-body-1"
            class="mx-4"
            aria-labelledby="create-product-accordion-collapse-heading-1"
          >
            <div class="py-4 border-gray-200 sm:py-5 dark:border-gray-700">
              <!-- Inputs -->
              <div class="grid gap-4 md:gap-6 md:grid-cols-2">
                <!-- Column -->
                <div class="space-y-4 sm:space-y-6">
                  <div>
                    <label
                      for="name"
                      class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                    >성명</label>
                    <input
                      id="name"
                      type="text"
                      name="name"
                      class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                      required=""
                      @input="visitor.visitorName = $event.target.value"
                    >
                  </div>
                  <div class="space-y-4 sm:flex sm:space-x-4 sm:space-y-0">
                    <div class="w-full">
                      <div class="w-full">
                        <label
                          for="price"
                          class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                        >소속</label>
                        <input
                          id="price"
                          type="text"
                          name="price"
                          class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                          required=""
                          @input="visitor.visitorSosok = $event.target.value"
                        >
                      </div>
                    </div>
                    <div class="w-full">
                      <label
                        for="price"
                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                      >계급</label>
                      <input
                        id="price"
                        type="text"
                        name="price"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                        placeholder="또는 직급"
                        required=""
                        @input="visitor.visitorOccupation = $event.target.value"
                      >
                    </div>
                  </div>
                  <div class="space-y-4 sm:flex sm:space-x-4 sm:space-y-0">
                    <div class="w-full">
                      <label
                        for="product-state"
                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                      >연락처</label>
                      <input
                        id="product-state"
                        type="text"
                        name="product-state"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                        required=""
                        @input="visitor.visitorCellPhoneNumber = $event.target.value"
                      >
                    </div>
                    <div class="w-full">
                      <label
                        for="brand"
                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                      >생년월일</label>
                      <input
                        id="brand"
                        type="date"
                        name="brand"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                        required=""
                        @input="visitor.visitorBirthdate = $event.target.value"
                      >
                    </div>
                  </div>
                  <div class="space-y-4 sm:flex sm:space-x-4 sm:space-y-0">
                    <div class="w-full">
                      <label
                        for="category"
                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                      >출입 종류</label>
                      <select
                        id="category"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                      >
                        <option selected="">
                          방문 출입
                        </option>
                        <option value="TV">
                          고정 출입
                        </option>
                        <option value="TV">
                          기관원
                        </option>
                        <option value="TV">
                          근로자
                        </option>
                      </select>
                    </div>
                    <div class="w-full">
                      <label
                        for="product-state"
                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                      >출입 장소</label>
                      <input
                        id="product-state"
                        type="text"
                        name="product-state"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                        required=""
                        @input="visitor.visitorPlace = $event.target.value"
                      >
                    </div>
                  </div>
                  <div class="space-y-4 sm:flex sm:space-x-4 sm:space-y-0">
                    <div class="w-full">
                      <label
                        for="return-policy"
                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                      >관련 근거</label>
                      <input
                        type="text"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                        placeholder="문서 번호"
                        required=""
                        @input="visitor.visitorPerpose = $event.target.value"
                      >
                    </div>
                  </div>
                  <div class="space-y-4 sm:flex sm:space-x-4 sm:space-y-0">
                    <div class="w-full">
                      <label
                        for="return-policy"
                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                      >출입 목적</label>
                      <input
                        type="text"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                        required=""
                        @input="visitor.visitorPerpose = $event.target.value"
                      >
                    </div>
                  </div>
                </div>
                <!-- Column -->
                <div class="">
                  <h4
                    class="mb-2 w-full text-sm text-gray-900 dark:text-white"
                  >
                    출입 기간
                  </h4>
                  <div class="space-y-4 sm:flex sm:space-x-4 sm:space-y-0">
                    <div class="w-full">
                      <input
                        type="datetime-local"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                        required=""
                        @input="visitor.visitStartDateTime = $event.target.value"
                      >
                    </div>
                    <span class="flex items-center font-extrabold">~</span>
                    <div class="w-full">
                      <input
                        type="datetime-local"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                        required=""
                        @input="visitor.visitEndDateTime = $event.target.value"
                      >
                    </div>
                  </div>
                  <div>
                    <h4
                      class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                    >
                      인증 방식
                    </h4>
                    <div
                      class="flex flex-col justify-center items-center w-full h-64 bg-gray-50 rounded-lg border-2 border-gray-300 border-dashed cursor-pointer dark:hover:bg-bray-800 dark:bg-gray-700 hover:bg-gray-100 dark:border-gray-600 dark:hover:border-gray-500 dark:hover:bg-gray-600"
                    >
                      <div class="flex flex-col justify-center items-center pt-5 pb-6">
                        <button
                          type="button"
                          class="py-2 px-3 text-xs font-medium text-center text-white bg-primary-700 rounded-lg hover:bg-primary-800 focus:ring-4 focus:outline-none focus:ring-primary-300 dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800"
                        >
                          지문
                        </button>
                        <button
                          type="button"
                          class="py-2 px-3 text-xs font-medium text-center text-white bg-primary-700 rounded-lg hover:bg-primary-800 focus:ring-4 focus:outline-none focus:ring-primary-300 dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800"
                        >
                          카드
                        </button>
                      </div>
                    </div>
                  </div>
                  <div>
                    <label
                      for="description"
                      class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                    >
                      비고
                    </label>
                    <input
                      name="description"
                      type="text"
                      class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                      required=""
                      @input="visitor.visitorPerpose = $event.target.value"
                    >
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div
          id="create-product-accordion-collapse-body-2"
          class="hidden"
          aria-labelledby="create-product-accordion-collapse-heading-2"
        >
          <div class="pt-4 border-gray-200 sm:pt-5 dark:border-gray-700">
            <!-- Inputs -->
            <div class="grid gap-4 md:gap-6 md:grid-cols-2">
              <!-- Column -->
              <div class="space-y-4 sm:space-y-6">
                <div class="space-y-4 sm:flex sm:space-x-4 sm:space-y-0">
                  <div class="w-full">
                    <label
                      for="discount"
                      class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                    >Discount Type</label>
                    <select
                      id="discount"
                      class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                    >
                      <option selected="">
                        Percent off
                      </option>
                      <option value="SU">
                        Sum
                      </option>
                    </select>
                  </div>
                  <div class="w-full">
                    <label
                      for="minimum-order"
                      class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                    >Minimum Order Amount</label>
                    <div class="relative">
                      <div class="flex absolute inset-y-0 left-0 items-center pl-3 pointer-events-none">
                        <svg
                          aria-hidden="true"
                          class="w-5 h-5 text-gray-500 dark:text-gray-400"
                          fill="currentColor"
                          viewBox="0 0 20 20"
                          xmlns="http://www.w3.org/2000/svg"
                        ><path d="M8.433 7.418c.155-.103.346-.196.567-.267v1.698a2.305 2.305 0 01-.567-.267C8.07 8.34 8 8.114 8 8c0-.114.07-.34.433-.582zM11 12.849v-1.698c.22.071.412.164.567.267.364.243.433.468.433.582 0 .114-.07.34-.433.582a2.305 2.305 0 01-.567.267z" /><path
                          fill-rule="evenodd"
                          d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-13a1 1 0 10-2 0v.092a4.535 4.535 0 00-1.676.662C6.602 6.234 6 7.009 6 8c0 .99.602 1.765 1.324 2.246.48.32 1.054.545 1.676.662v1.941c-.391-.127-.68-.317-.843-.504a1 1 0 10-1.51 1.31c.562.649 1.413 1.076 2.353 1.253V15a1 1 0 102 0v-.092a4.535 4.535 0 001.676-.662C13.398 13.766 14 12.991 14 12c0-.99-.602-1.765-1.324-2.246A4.535 4.535 0 0011 9.092V7.151c.391.127.68.317.843.504a1 1 0 101.511-1.31c-.563-.649-1.413-1.076-2.354-1.253V5z"
                          clip-rule="evenodd"
                        /></svg>
                      </div>
                      <input
                        id="minimum-order"
                        type="number"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full pl-10 p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                        placeholder="400"
                      >
                    </div>
                  </div>
                </div>
                <div class="w-full">
                  <label
                    for="discount-worth"
                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                  >Discount worth</label>
                  <div class="relative">
                    <div class="flex absolute inset-y-0 left-0 items-center pl-3 pointer-events-none">
                      <svg
                        aria-hidden="true"
                        class="w-5 h-5 text-gray-500 dark:text-gray-400"
                        fill="currentColor"
                        viewBox="0 0 20 20"
                        xmlns="http://www.w3.org/2000/svg"
                      ><path
                        fill-rule="evenodd"
                        d="M5 2a2 2 0 00-2 2v14l3.5-2 3.5 2 3.5-2 3.5 2V4a2 2 0 00-2-2H5zm2.5 3a1.5 1.5 0 100 3 1.5 1.5 0 000-3zm6.207.293a1 1 0 00-1.414 0l-6 6a1 1 0 101.414 1.414l6-6a1 1 0 000-1.414zM12.5 10a1.5 1.5 0 100 3 1.5 1.5 0 000-3z"
                        clip-rule="evenodd"
                      /></svg>
                    </div>
                    <input
                      id="discount-worth"
                      type="number"
                      class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full pl-10 p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                      placeholder="10"
                    >
                  </div>
                </div>
                <div class="flex items-center">
                  <input
                    id="offer-checkbox"
                    type="checkbox"
                    value=""
                    class="w-4 h-4 text-primary-600 bg-gray-100 rounded border-gray-300 focus:ring-primary-500 dark:focus:ring-primary-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
                  >
                  <label
                    for="offer-checkbox"
                    class="ml-2 text-sm text-gray-500 dark:text-gray-300"
                  >I understand that the discount given in this offer will be borne by me</label>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="flex justify-end">
        <button
          type="submit"
          class=" inline-flex items-center px-5 py-2.5 mt-4 sm:mt-6 text-sm font-medium text-center text-white bg-primary-700 rounded-lg focus:ring-4 focus:ring-primary-200 dark:focus:ring-primary-900 hover:bg-primary-800"
          @click="createVisitor"
        >
          등록
        </button>
      </div>
    </div>
  </section>
</template>

<style scoped>

</style>
