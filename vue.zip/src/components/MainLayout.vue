<script setup>
import MainHeader from "@/components/MainHeader.vue";
import MainAside from "@/components/MainAside.vue";
</script>

<template>
  <main-header />
  <main-aside />
  <router-view />
</template>

<style scoped>
</style>
