<script setup></script>

<template>
  <div class="flex h-full bg-gray-50 dark:bg-gray-900">
    <div
      id="sidebarBackdrop"
      class="fixed inset-0 z-10 hidden bg-gray-900/50 dark:bg-gray-900/90"
    />
    <div
      id="main-content"
      class="relative w-full overflow-y-auto bg-gray-50 dark:bg-gray-900 lg:ml-64"
    >
      <main class="h-full">
        <div class="h-full px-4 pt-6">
          <div
            class="mt-4 grid w-full grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3"
          >
            <div
              class="rounded-lg bg-white p-4 shadow dark:bg-gray-800 sm:p-6 xl:p-8"
            >
              <div class="flex items-center">
                <div class="flex-shrink-0">
                  <span
                    class="text-2xl font-bold leading-none text-gray-900 dark:text-white sm:text-3xl"
                    >34</span
                  >
                  <h3
                    class="mb-3 text-base font-normal text-gray-500 dark:text-gray-400"
                  >
                    현재 출입자
                  </h3>
                </div>
                <div
                  class="invisible ml-5 flex w-0 flex-1 items-center justify-end text-base font-bold text-green-500 dark:text-green-400"
                >
                  14.6%
                  <svg
                    class="h-5 w-5"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      fill-rule="evenodd"
                      d="M5.293 7.707a1 1 0 010-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 01-1.414 1.414L11 5.414V17a1 1 0 11-2 0V5.414L6.707 7.707a1 1 0 01-1.414 0z"
                      clip-rule="evenodd"
                    />
                  </svg>
                </div>
              </div>
              <div id="new-products-chart" />
              <!-- Card Footer -->
              <div
                class="flex items-center justify-between border-t border-gray-200 pt-3 dark:border-gray-700 sm:pt-6"
              >
                <div class="invisible">
                  <button
                    class="inline-flex items-center rounded-lg p-2 text-center text-sm font-medium text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white"
                    type="button"
                    data-dropdown-toggle="new-products-dropdown"
                  >
                    Last 7 days
                    <svg
                      class="ml-2 h-4 w-4"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"
                        d="M19 9l-7 7-7-7"
                      />
                    </svg>
                  </button>
                  <!-- Dropdown menu -->
                  <div
                    id="new-products-dropdown"
                    class="z-50 my-4 hidden list-none divide-y divide-gray-100 rounded bg-white text-base shadow dark:divide-gray-600 dark:bg-gray-700"
                  >
                    <div class="px-4 py-3" role="none">
                      <p
                        class="truncate text-sm font-medium text-gray-900 dark:text-white"
                        role="none"
                      >
                        Sep 16, 2021 - Sep 22, 2021
                      </p>
                    </div>
                    <ul class="py-1" role="none">
                      <li>
                        <a
                          href="#"
                          class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-600 dark:hover:text-white"
                          role="menuitem"
                          >Yesterday</a
                        >
                      </li>
                      <li>
                        <a
                          href="#"
                          class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-600 dark:hover:text-white"
                          role="menuitem"
                          >Today</a
                        >
                      </li>
                      <li>
                        <a
                          href="#"
                          class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-600 dark:hover:text-white"
                          role="menuitem"
                          >Last 7 days</a
                        >
                      </li>
                      <li>
                        <a
                          href="#"
                          class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-600 dark:hover:text-white"
                          role="menuitem"
                          >Last 30 days</a
                        >
                      </li>
                      <li>
                        <a
                          href="#"
                          class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-600 dark:hover:text-white"
                          role="menuitem"
                          >Last 90 days</a
                        >
                      </li>
                    </ul>
                    <div class="py-1" role="none">
                      <a
                        href="#"
                        class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-600 dark:hover:text-white"
                        role="menuitem"
                        >Custom...</a
                      >
                    </div>
                  </div>
                </div>
                <div class="flex-shrink-0">
                  <router-link to="/visitor">
                    <div
                      class="inline-flex items-center rounded-lg p-2 text-sm font-bold uppercase text-primary-700 hover:bg-gray-100 dark:text-primary-500 dark:hover:bg-gray-700 sm:text-sm"
                    >
                      출입자 목록
                      <svg
                        class="ml-1 h-4 w-4 sm:h-5 sm:w-5"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          stroke-width="2"
                          d="M9 5l7 7-7 7"
                        />
                      </svg>
                    </div>
                  </router-link>
                </div>
              </div>
            </div>

            <div
              class="rounded-lg bg-white p-4 shadow dark:bg-gray-800 sm:p-6 xl:p-8"
            >
              <div class="flex items-center">
                <div class="flex-shrink-0">
                  <span
                    class="text-2xl font-bold leading-none text-gray-900 dark:text-white sm:text-3xl"
                    >24</span
                  >
                  <h3
                    class="text-base font-normal text-gray-500 dark:text-gray-400"
                  >
                    현재 출입 차량
                  </h3>
                </div>
                <div
                  class="invisible ml-5 flex w-0 flex-1 items-center justify-end text-base font-bold text-green-500 dark:text-green-400"
                >
                  32.9%
                  <svg
                    class="h-5 w-5"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      fill-rule="evenodd"
                      d="M5.293 7.707a1 1 0 010-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 01-1.414 1.414L11 5.414V17a1 1 0 11-2 0V5.414L6.707 7.707a1 1 0 01-1.414 0z"
                      clip-rule="evenodd"
                    />
                  </svg>
                </div>
              </div>
              <div id="visitors-chart" />
              <!-- Card Footer -->
              <div
                class="mt-3.5 flex items-center justify-between border-t border-gray-200 pt-3 dark:border-gray-700 sm:pt-6"
              >
                <div>
                  <button
                    class="invisible inline-flex items-center rounded-lg p-2 text-center text-sm font-medium text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white"
                    type="button"
                    data-dropdown-toggle="visitors-dropdown"
                  >
                    지난 30일
                    <svg
                      class="ml-2 h-4 w-4"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"
                        d="M19 9l-7 7-7-7"
                      />
                    </svg>
                  </button>
                  <!-- Dropdown menu -->
                  <div
                    id="visitors-dropdown"
                    class="z-50 my-4 hidden list-none divide-y divide-gray-100 rounded bg-white text-base shadow dark:divide-gray-600 dark:bg-gray-700"
                  >
                    <div class="px-4 py-3" role="none">
                      <p
                        class="truncate text-sm font-medium text-gray-900 dark:text-white"
                        role="none"
                      >
                        Sep 16, 2021 - Sep 22, 2021
                      </p>
                    </div>
                    <ul class="py-1" role="none">
                      <li>
                        <a
                          href="#"
                          class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-600 dark:hover:text-white"
                          role="menuitem"
                          >Yesterday</a
                        >
                      </li>
                      <li>
                        <a
                          href="#"
                          class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-600 dark:hover:text-white"
                          role="menuitem"
                          >Today</a
                        >
                      </li>
                      <li>
                        <a
                          href="#"
                          class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-600 dark:hover:text-white"
                          role="menuitem"
                          >Last 7 days</a
                        >
                      </li>
                      <li>
                        <a
                          href="#"
                          class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-600 dark:hover:text-white"
                          role="menuitem"
                          >Last 30 days</a
                        >
                      </li>
                      <li>
                        <a
                          href="#"
                          class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-600 dark:hover:text-white"
                          role="menuitem"
                          >Last 90 days</a
                        >
                      </li>
                    </ul>
                    <div class="py-1" role="none">
                      <a
                        href="#"
                        class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-600 dark:hover:text-white"
                        role="menuitem"
                        >Custom...</a
                      >
                    </div>
                  </div>
                </div>
                <div class="flex-shrink-0">
                  <a
                    href="#"
                    class="inline-flex items-center rounded-lg p-2 text-xs font-bold font-medium uppercase text-primary-700 hover:bg-gray-100 dark:text-primary-500 dark:hover:bg-gray-700 sm:text-sm"
                  >
                    출입 차량 목록
                    <svg
                      class="ml-1 h-4 w-4 sm:h-5 sm:w-5"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"
                        d="M9 5l7 7-7 7"
                      />
                    </svg>
                  </a>
                </div>
              </div>
            </div>
            <div
              class="rounded-lg bg-white p-4 shadow dark:bg-gray-800 sm:p-6 xl:p-8"
            >
              <div class="flex items-center">
                <div class="flex-shrink-0">
                  <span
                    class="text-2xl font-bold leading-none text-gray-900 dark:text-white sm:text-3xl"
                    >385</span
                  >
                  <h3
                    class="text-base font-normal text-gray-500 dark:text-gray-400"
                  >
                    출입 신청자
                  </h3>
                </div>
                <div
                  class="invisible ml-5 flex w-0 flex-1 items-center justify-end text-base font-bold text-red-500 dark:text-red-400"
                >
                  -2.7%
                  <svg
                    class="h-5 w-5"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      fill-rule="evenodd"
                      d="M14.707 12.293a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 111.414-1.414L9 14.586V3a1 1 0 012 0v11.586l2.293-2.293a1 1 0 011.414 0z"
                      clip-rule="evenodd"
                    />
                  </svg>
                </div>
              </div>
              <div id="week-signups-chart" />
              <!-- Card Footer -->
              <div
                class="flex items-center justify-between border-t border-gray-200 pt-3 dark:border-gray-700 sm:pt-6"
              >
                <div>
                  <button
                    class="inline-flex hidden items-center rounded-lg p-2 text-center text-sm font-medium text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white"
                    type="button"
                    data-dropdown-toggle="week-signups-dropdown"
                  >
                    Last 7 days
                    <svg
                      class="ml-2 h-4 w-4"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"
                        d="M19 9l-7 7-7-7"
                      />
                    </svg>
                  </button>
                  <!-- Dropdown menu -->
                  <div
                    id="week-signups-dropdown"
                    class="z-50 my-4 hidden list-none divide-y divide-gray-100 rounded bg-white text-base shadow dark:divide-gray-600 dark:bg-gray-700"
                  >
                    <div class="px-4 py-3" role="none">
                      <p
                        class="truncate text-sm font-medium text-gray-900 dark:text-white"
                        role="none"
                      >
                        Sep 16, 2021 - Sep 22, 2021
                      </p>
                    </div>
                    <ul class="py-1" role="none">
                      <li>
                        <a
                          href="#"
                          class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-600 dark:hover:text-white"
                          role="menuitem"
                          >Yesterday</a
                        >
                      </li>
                      <li>
                        <a
                          href="#"
                          class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-600 dark:hover:text-white"
                          role="menuitem"
                          >Today</a
                        >
                      </li>
                      <li>
                        <a
                          href="#"
                          class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-600 dark:hover:text-white"
                          role="menuitem"
                          >Last 7 days</a
                        >
                      </li>
                      <li>
                        <a
                          href="#"
                          class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-600 dark:hover:text-white"
                          role="menuitem"
                          >Last 30 days</a
                        >
                      </li>
                      <li>
                        <a
                          href="#"
                          class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-600 dark:hover:text-white"
                          role="menuitem"
                          >Last 90 days</a
                        >
                      </li>
                    </ul>
                    <div class="py-1" role="none">
                      <a
                        href="#"
                        class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-600 dark:hover:text-white"
                        role="menuitem"
                        >Custom...</a
                      >
                    </div>
                  </div>
                </div>
                <div class="flex-shrink-0">
                  <a
                    href="#"
                    class="inline-flex items-center rounded-lg p-2 text-xs font-bold font-medium uppercase text-primary-700 hover:bg-gray-100 dark:text-primary-500 dark:hover:bg-gray-700 sm:text-sm"
                  >
                    신청자 목록
                    <svg
                      class="ml-1 h-4 w-4 sm:h-5 sm:w-5"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"
                        d="M9 5l7 7-7 7"
                      />
                    </svg>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  </div>
</template>

<style scoped></style>
