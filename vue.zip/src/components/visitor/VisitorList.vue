<script setup>
</script>

<template>
  <div class="bg-gray-50 dark:bg-gray-800">
    <div class="flex overflow-hidden bg-gray-50 dark:bg-gray-900">
      <div
        id="main-content"
        class="overflow-y-auto relative w-full h-full bg-gray-50 lg:ml-64 dark:bg-gray-900"
      >
        <main>
          <div
            class="p-4 bg-white block sm:flex items-center justify-between border-b border-gray-200 dark:bg-gray-800 dark:border-gray-700"
          >
            <ol class="inline-flex items-center space-x-1 md:space-x-2">
              <li class="inline-flex items-center">
                <a
                  href="#"
                  class="inline-flex items-center text-gray-700 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white"
                >
                  <svg
                    class="w-5 h-5 mr-2.5"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"
                    />
                  </svg>
                  홈
                </a>
              </li>
              <li>
                <div class="flex items-center">
                  <svg
                    class="w-6 h-6 text-gray-400"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      fill-rule="evenodd"
                      d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                      clip-rule="evenodd"
                    />
                  </svg>
                  <a
                    href="#"
                    class="ml-1 text-sm font-medium text-gray-700 hover:text-gray-900 md:ml-2 dark:text-gray-300 dark:hover:text-white"
                  >방문자</a>
                </div>
              </li>
              <li>
                <div class="flex items-center">
                  <svg
                    class="w-6 h-6 text-gray-400"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      fill-rule="evenodd"
                      d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                      clip-rule="evenodd"
                    />
                  </svg>
                  <span
                    class="ml-1 text-sm font-medium text-gray-400 md:ml-2 dark:text-gray-500"
                    aria-current="page"
                  >전체</span>
                </div>
              </li>
            </ol>
          </div>
          <div class="flex flex-col">
            <div class="overflow-x-auto">
              <div class="inline-block min-w-full align-middle">
                <div class="overflow-hidden shadow">
                  <table
                    class="min-w-full divide-y divide-gray-200 table-fixed dark:divide-gray-600"
                  >
                    <thead class="bg-gray-100 dark:bg-gray-700">
                      <tr>
                        <th
                          scope="col"
                          class="p-4"
                        >
                          <div class="flex items-center">
                            <input
                              id="checkbox-all"
                              aria-describedby="checkbox-1"
                              type="checkbox"
                              class="w-4 h-4 bg-gray-50 rounded border-gray-300 focus:ring-3 focus:ring-primary-300 dark:focus:ring-primary-600 dark:ring-offset-gray-800 dark:bg-gray-700 dark:border-gray-600"
                            >
                            <label
                              for="checkbox-all"
                              class="sr-only"
                            >checkbox</label>
                          </div>
                        </th>
                        <th
                          scope="col"
                          class="p-4 text-xs font-medium text-left text-gray-500 uppercase dark:text-gray-400"
                        >
                          방문자
                        </th>
                        <th
                          scope="col"
                          class="p-4 text-xs font-medium text-left text-gray-500 uppercase dark:text-gray-400"
                        >
                          소속
                        </th>
                        <th
                          scope="col"
                          class="p-4 text-xs font-medium text-left text-gray-500 uppercase dark:text-gray-400"
                        >
                          방문 목적
                        </th>
                        <th
                          scope="col"
                          class="p-4 text-xs font-medium text-left text-gray-500 uppercase dark:text-gray-400"
                        >
                          방문 장소
                        </th>
                        <th
                          scope="col"
                          class="p-4 text-xs font-medium text-left text-gray-500 uppercase dark:text-gray-400"
                        >
                          방문일시
                        </th>
                        <th
                          scope="col"
                          class="p-4 text-xs font-medium text-left text-gray-500 uppercase dark:text-gray-400"
                        >
                          승인 상태
                        </th>
                        <th
                          scope="col"
                          class="p-4 text-xs font-medium text-left text-gray-500 uppercase dark:text-gray-400"
                        >
                          차량 정보
                        </th>
                      </tr>
                    </thead>

                    <!-- 방문자 정보 시작 -->
                    <tbody
                      class="bg-white divide-y divide-gray-200 dark:bg-gray-800 dark:divide-gray-700"
                    >
                      <template
                        v-for="visitor in list"
                        :key="visitor.id"
                      >
                        <tr class="hover:bg-gray-100 dark:hover:bg-gray-700">
                          <td class="p-4 w-4">
                            <div class="flex items-center">
                              <input
                                id="checkbox-1"
                                aria-describedby="checkbox-1"
                                type="checkbox"
                                class="w-4 h-4 bg-gray-50 rounded border-gray-300 focus:ring-3 focus:ring-primary-300 dark:focus:ring-primary-600 dark:ring-offset-gray-800 dark:bg-gray-700 dark:border-gray-600"
                              >
                              <label
                                for="checkbox-1"
                                class="sr-only"
                              >checkbox</label>
                            </div>
                          </td>
                          <!-- 이름 및 전화번호 -->
                          <td
                            class="flex items-center p-4 mr-12 space-x-6 whitespace-nowrap lg:mr-0"
                          >
                            <div class="text-sm font-normal text-gray-500 dark:text-gray-400">
                              <div
                                class="text-base font-semibold text-gray-900 dark:text-white"
                              >
                                {{ visitor.visitorName }}
                              </div>

                              <div class="text-sm font-normal text-gray-500 dark:text-gray-400">
                                {{ visitor.phoneNumber }}
                              </div>
                            </div>
                          </td>
                          <td
                            class="p-4 text-base font-medium text-gray-900 whitespace-nowrap dark:text-white"
                          >
                            {{ visitor.sosok }}
                            <div class="text-sm font-normal text-gray-500 dark:text-gray-400">
                              {{ visitor.visitorOccupation }}
                            </div>
                          </td>
                          <td
                            class="p-4 text-base font-medium text-gray-900 whitespace-nowrap dark:text-white"
                          >
                            {{ visitor.visitPurpose }}
                          </td>
                          <td
                            class="p-4 text-base font-medium text-gray-900 whitespace-nowrap dark:text-white"
                          >
                            {{ visitor.visitPlace }}
                          </td>
                          <td
                            class="p-4 text-base font-normal text-gray-900 whitespace-nowrap dark:text-white"
                          >
                            <div>{{ visitor.visitStartTime }}</div>
                            <div>~ {{ visitor.visitEndTime }}</div>
                          </td>
                          <td
                            class="p-4 text-base font-normal text-gray-900 whitespace-nowrap dark:text-white"
                          >
                            <div class="flex items-center">
                              <div class="h-2.5 w-2.5 rounded-full bg-yellow-400 mr-2" />
                              대기
                            </div>
                          </td>
                          <td
                            class="p-4 text-base font-normal text-gray-900 whitespace-nowrap dark:text-white"
                          />
                        </tr>
                      </template>
                    </tbody>
                    <!-- 방문자 정보 끝 -->
                  </table>
                </div>
              </div>
            </div>
          </div>
          <div
            class="sticky right-0 bottom-0 items-center p-4 w-full bg-white border-t border-gray-200 sm:flex sm:justify-between dark:bg-gray-800 dark:border-gray-700"
          >
            <div class="invisible flex items-center mb-4 sm:mb-0">
              <a
                href="#"
                class="inline-flex justify-center p-1 text-gray-500 rounded cursor-pointer hover:text-gray-900 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white"
              >
                <svg
                  class="w-7 h-7"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    fill-rule="evenodd"
                    d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z"
                    clip-rule="evenodd"
                  />
                </svg>
              </a>
              <a
                href="#"
                class="inline-flex justify-center p-1 mr-2 text-gray-500 rounded cursor-pointer hover:text-gray-900 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white"
              >
                <svg
                  class="w-7 h-7"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    fill-rule="evenodd"
                    d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                    clip-rule="evenodd"
                  />
                </svg>
              </a>
              <span class="text-sm font-normal text-gray-500 dark:text-gray-400">Showing <span class="font-semibold text-gray-900 dark:text-white">1-20</span> of
                <span class="font-semibold text-gray-900 dark:text-white">2290</span></span>
            </div>
          </div>

          <!-- Modal -->
          <div
            id="user-modal"
            class="hidden overflow-y-auto overflow-x-hidden fixed right-0 left-0 top-4 z-50 justify-center items-center md:inset-0 h-modal sm:h-full"
          >
            <div class="relative px-4 w-full max-w-2xl h-full md:h-auto">
              <!-- Modal content -->
              <div class="relative bg-white rounded-lg shadow dark:bg-gray-800">
                <!-- Modal header -->
                <div
                  class="flex justify-between items-start p-5 rounded-t border-b dark:border-gray-700"
                >
                  <h3 class="text-xl font-semibold dark:text-white">
                    Edit user
                  </h3>
                  <button
                    type="button"
                    class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center dark:hover:bg-gray-700 dark:hover:text-white"
                    data-modal-toggle="user-modal"
                  >
                    <svg
                      class="w-5 h-5"
                      fill="currentColor"
                      viewBox="0 0 20 20"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        fill-rule="evenodd"
                        d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                        clip-rule="evenodd"
                      />
                    </svg>
                  </button>
                </div>
                <!-- Modal body -->
                <div class="p-6 space-y-6">
                  <form action="#">
                    <div class="grid grid-cols-6 gap-6">
                      <div class="col-span-6 sm:col-span-3">
                        <label
                          for="first-name"
                          class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                        >First Name</label>
                        <input
                          id="first-name"
                          type="text"
                          name="first-name"
                          class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                          placeholder="Bonnie"
                          required
                        >
                      </div>
                      <div class="col-span-6 sm:col-span-3">
                        <label
                          for="last-name"
                          class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                        >Last Name</label>
                        <input
                          id="last-name"
                          type="text"
                          name="last-name"
                          class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                          placeholder="Green"
                          required
                        >
                      </div>
                      <div class="col-span-6 sm:col-span-3">
                        <label
                          for="email"
                          class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                        >Email</label>
                        <input
                          id="email"
                          type="email"
                          name="email"
                          class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                          placeholder="example@company.com"
                          required
                        >
                      </div>
                      <div class="col-span-6 sm:col-span-3">
                        <label
                          for="phone-number"
                          class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                        >Phone Number</label>
                        <input
                          id="phone-number"
                          type="number"
                          name="phone-number"
                          class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                          placeholder="e.g. +(12)3456 789"
                          required
                        >
                      </div>
                      <div class="col-span-6 sm:col-span-3">
                        <label
                          for="department"
                          class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                        >Department</label>
                        <input
                          id="department"
                          type="text"
                          name="department"
                          class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                          placeholder="Development"
                          required
                        >
                      </div>
                      <div class="col-span-6 sm:col-span-3">
                        <label
                          for="company"
                          class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                        >Company</label>
                        <input
                          id="company"
                          type="number"
                          name="company"
                          class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                          placeholder="123456"
                          required
                        >
                      </div>
                      <div class="col-span-6 sm:col-span-3">
                        <label
                          for="current-password"
                          class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                        >Current Password</label>
                        <input
                          id="current-password"
                          type="password"
                          name="current-password"
                          class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                          placeholder="••••••••"
                          required
                        >
                      </div>
                      <div class="col-span-6 sm:col-span-3">
                        <label
                          for="new-password"
                          class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                        >New Password</label>
                        <input
                          id="new-password"
                          type="password"
                          name="new-password"
                          class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                          placeholder="••••••••"
                          required
                        >
                      </div>
                    </div>
                  </form>
                </div>
                <!-- Modal footer -->
                <div
                  class="items-center p-6 rounded-b border-t border-gray-200 dark:border-gray-700"
                >
                  <button
                    class="text-white bg-primary-700 hover:bg-primary-800 focus:ring-4 focus:ring-primary-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800"
                    type="submit"
                  >
                    Save all
                  </button>
                </div>
              </div>
            </div>
          </div>

          <!-- Add User Modal -->
          <div
            id="add-user-modal"
            class="hidden overflow-y-auto overflow-x-hidden fixed right-0 left-0 top-4 z-50 justify-center items-center md:inset-0 h-modal sm:h-full"
          >
            <div class="relative px-4 w-full max-w-2xl h-full md:h-auto">
              <!-- Modal content -->
              <div class="relative bg-white rounded-lg shadow dark:bg-gray-800">
                <!-- Modal header -->
                <div
                  class="flex justify-between items-start p-5 rounded-t border-b dark:border-gray-700"
                >
                  <h3 class="text-xl font-semibold dark:text-white">
                    Add new user
                  </h3>
                  <button
                    type="button"
                    class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center dark:hover:bg-gray-700 dark:hover:text-white"
                    data-modal-toggle="add-user-modal"
                  >
                    <svg
                      class="w-5 h-5"
                      fill="currentColor"
                      viewBox="0 0 20 20"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        fill-rule="evenodd"
                        d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                        clip-rule="evenodd"
                      />
                    </svg>
                  </button>
                </div>
                <!-- Modal body -->
                <div class="p-6 space-y-6">
                  <form action="#">
                    <div class="grid grid-cols-6 gap-6">
                      <div class="col-span-6 sm:col-span-3">
                        <label
                          for="first-name"
                          class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                        >First Name</label>
                        <input
                          id="first-name"
                          type="text"
                          name="first-name"
                          class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                          placeholder="Bonnie"
                          required
                        >
                      </div>
                      <div class="col-span-6 sm:col-span-3">
                        <label
                          for="last-name"
                          class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                        >Last Name</label>
                        <input
                          id="last-name"
                          type="text"
                          name="last-name"
                          class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                          placeholder="Green"
                          required
                        >
                      </div>
                      <div class="col-span-6 sm:col-span-3">
                        <label
                          for="email"
                          class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                        >Email</label>
                        <input
                          id="email"
                          type="email"
                          name="email"
                          class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                          placeholder="example@company.com"
                          required
                        >
                      </div>
                      <div class="col-span-6 sm:col-span-3">
                        <label
                          for="phone-number"
                          class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                        >Phone Number</label>
                        <input
                          id="phone-number"
                          type="number"
                          name="phone-number"
                          class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                          placeholder="e.g. +(12)3456 789"
                          required
                        >
                      </div>
                      <div class="col-span-6 sm:col-span-3">
                        <label
                          for="department"
                          class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                        >Department</label>
                        <input
                          id="department"
                          type="text"
                          name="department"
                          class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                          placeholder="Development"
                          required
                        >
                      </div>
                      <div class="col-span-6 sm:col-span-3">
                        <label
                          for="company"
                          class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                        >Company</label>
                        <input
                          id="company"
                          type="number"
                          name="company"
                          class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                          placeholder="123456"
                          required
                        >
                      </div>
                    </div>
                  </form>
                </div>
                <!-- Modal footer -->
                <div
                  class="items-center p-6 rounded-b border-t border-gray-200 dark:border-gray-700"
                >
                  <button
                    class="text-white bg-primary-700 hover:bg-primary-800 focus:ring-4 focus:ring-primary-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800"
                    type="submit"
                  >
                    Add user
                  </button>
                </div>
              </div>
            </div>
          </div>

          <!-- Delete User Modal -->
          <div
            id="delete-user-modal"
            class="hidden overflow-y-auto overflow-x-hidden fixed right-0 left-0 top-4 z-50 justify-center items-center md:inset-0 h-modal sm:h-full"
          >
            <div class="relative px-4 w-full max-w-md h-full md:h-auto">
              <!-- Modal content -->
              <div class="relative bg-white rounded-lg shadow dark:bg-gray-800">
                <!-- Modal header -->
                <div class="flex justify-end p-2">
                  <button
                    type="button"
                    class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center dark:hover:bg-gray-700 dark:hover:text-white"
                    data-modal-toggle="delete-user-modal"
                  >
                    <svg
                      class="w-5 h-5"
                      fill="currentColor"
                      viewBox="0 0 20 20"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        fill-rule="evenodd"
                        d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                        clip-rule="evenodd"
                      />
                    </svg>
                  </button>
                </div>
                <!-- Modal body -->
                <div class="p-6 pt-0 text-center">
                  <svg
                    class="mx-auto w-20 h-20 text-red-600"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      stroke-linecap="round"
                      stroke-linejoin="round"
                      stroke-width="2"
                      d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                  <h3 class="mt-5 mb-6 text-xl font-normal text-gray-500 dark:text-gray-400">
                    Are you sure you want to delete this user?
                  </h3>
                  <a
                    href="#"
                    class="text-white bg-red-600 hover:bg-red-800 focus:ring-4 focus:ring-red-300 font-medium rounded-lg text-base inline-flex items-center px-3 py-2.5 text-center mr-2 dark:focus:ring-red-800"
                  >
                    Yes, I'm sure
                  </a>
                  <a
                    href="#"
                    class="text-gray-900 bg-white hover:bg-gray-100 focus:ring-4 focus:ring-primary-300 border border-gray-200 font-medium inline-flex items-center rounded-lg text-base px-3 py-2.5 text-center dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700 dark:focus:ring-gray-700"
                    data-modal-toggle="delete-user-modal"
                  >
                    No, cancel
                  </a>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  </div>
</template>
<script>
import axios from "axios"
export default {
  data() {
    return {
      list:[]
    }
  },

  mounted() {
    this.visitorGetList();
  },

  methods : {
    visitorGetList() {
      axios.get("http://localhost:8080/visitor").then((res) => {
        console.log(res.data);
        this.list = res.data;
      });
    }
  }
}
</script>
<style scoped></style>
