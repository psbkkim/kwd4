<script setup>
import router from "@/router";
import {reactive} from "vue";
import {FwbAccordion, FwbAccordionContent, FwbAccordionHeader, FwbAccordionPanel} from "flowbite-vue";

const visitor = reactive({
  visitorName: String,
  visitorBirthdate: Date,
  visitorSosok: String,
  visitorOccupation: String,
  visitorCellPhoneNumber: String,
  visitorOtherPhoneNumber: String,
  visitorPlace: String,
  visitorCarNumber: String,
  visitStartDateTime: Date,
  visitEndDateTime: Date,
  visitorPerpose: String,
  v_carkind: String,
  v_cardid: String,
  v_carcolor: String,
})


</script>

<template>
  <form class="mx-auto ml-64 max-w-6xl mb-4">
    <div class="bg-white min-h-fit rounded-lg border-16 border-white">
      <span class="block mb-2 font-bold text-lg">출입자 정보</span>
      <div class="block ml-2 mr-2 py-4 border-gray-200 sm:py-5 dark:border-gray-700">
        <!-- Inputs -->
        <div class="grid gap-4 md:gap-6 md:grid-cols-2">
          <!-- Column -->
          <div class="space-y-4 sm:space-y-4">  
            <div>
              <label
                for="name"
                class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
              >성명</label>
              <input
                id="name"
                type="text"
                name="name"
                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                required=""
                @input="visitor.visitorName = $event.target.value"
              >
            </div>
            <div class="space-y-4 sm:flex sm:space-x-4 sm:space-y-0">
              <div class="w-full">
                <div class="w-full">
                  <label
                    for="price"
                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                  >소속</label>
                  <input
                    id="price"
                    type="text"
                    name="price"
                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                    required=""
                    @input="visitor.visitorSosok = $event.target.value"
                  >
                </div>
              </div>
              <div class="w-full">
                <label
                  for="price"
                  class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                >계급</label>
                <input
                  id="price"
                  type="text"
                  name="price"
                  class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                  placeholder="또는 직급"
                  required=""
                  @input="visitor.visitorOccupation = $event.target.value"
                > 
              </div>
            </div>
            <div class="space-y-4 sm:flex sm:space-x-4 sm:space-y-0">
              <div class="w-full">
                <label
                  for="product-state"
                  class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                >연락처</label>
                <input
                  id="product-state"
                  type="text"
                  name="product-state"
                  class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                  required=""
                  @input="visitor.visitorCellPhoneNumber = $event.target.value"
                >
              </div>
              <div class="w-full">
                <label
                  for="brand"
                  class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                >생년월일/순번</label>
                <input
                  id="brand"
                  type="date"
                  name="brand"
                  class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                  required=""
                  @input="visitor.visitorBirthdate = $event.target.value"
                >
              </div>
            </div>
            <div class="space-y-4 sm:flex sm:space-x-4 sm:space-y-0">
              <div class="w-full">
                <label
                  for="category"
                  class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                >출입 구분</label>
                <select
                  id="category"
                  class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                >
                  <option selected="">
                    방문 출입
                  </option>
                  <option value="TV">
                    고정 출입
                  </option>
                  <option value="TV">
                    공무직 근로자
                  </option>
                </select>
              </div>
              <div class="w-full">
                <label
                  for="product-state"
                  class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                >출입 장소</label>
                <input
                  id="product-state"
                  type="text"
                  name="product-state"
                  class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                  required=""
                  @input="visitor.visitorPlace = $event.target.value"
                >
              </div>
            </div>
            <div class="space-y-4 sm:flex sm:space-x-4 sm:space-y-0">
              <div class="w-full">
                <label
                  for="return-policy"
                  class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                >관련 근거</label>
                <input
                  type="text"
                  class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                  placeholder="문서 번호"
                  required=""
                  @input="visitor.visitorPerpose = $event.target.value"
                >
              </div>
            </div>
            <div class="space-y-4 sm:flex sm:space-x-4 sm:space-y-0">
              <div class="w-full">
                <label
                  for="return-policy"
                  class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                >출입 목적</label>
                <input
                  type="text"
                  class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                  required=""
                  @input="visitor.visitorPerpose = $event.target.value"
                >
              </div>
            </div>
          </div>
          <!-- Column -->
          <div>
            <label
              class="block mb-2 w-full text-sm text-gray-900 dark:text-white"
            >
              출입 기간
            </label>
            <div class="sm:flex sm:space-x-4">
              <div class="w-full">
                <input
                  type="date"
                  class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                  required=""
                  @input="visitor.visitStartDateTime = $event.target.value"
                >
              </div>
              <span class="flex items-center font-extrabold">~</span>
              <div class="w-full">
                <input
                  type="date"
                  class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                  required=""
                  @input="visitor.visitEndDateTime = $event.target.value"
                >
              </div>
            </div>
            <div class="hidden">
              <label
                class="block mt-4 mb-2 text-sm font-medium text-gray-900 dark:text-white"
              >
                인증 방식
              </label>
              <div
                class="flex flex-col justify-center items-center w-full h-32 bg-gray-60 rounded-lg border-2 border-gray-300 border-dashed cursor-pointer dark:hover:bg-bray-800 dark:bg-gray-700 hover:bg-gray-100 dark:border-gray-600 dark:hover:border-gray-500 dark:hover:bg-gray-600"
              >
                <div class="flex flex-col justify-center items-center pt-4 pb-6">
                  <button
                    type="button"
                    class="py-2 px-3 text-xs font-medium text-center text-white bg-primary-700 rounded-lg hover:bg-primary-800 focus:ring-4 focus:outline-none focus:ring-primary-300 dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800"
                  >
                    지문
                  </button>
                  <button
                    type="button"
                    class="py-2 px-3 text-xs font-medium text-center text-white bg-primary-700 rounded-lg hover:bg-primary-800 focus:ring-4 focus:outline-none focus:ring-primary-300 dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800"
                  >
                    카드
                  </button>
                </div>
              </div>
            </div>
            <div class="hidden">
              <label
                for="description"
                class="block mt-4 mb-2 text-sm font-medium text-gray-900 dark:text-white"
              >
                비고
              </label>
              <input
                name="description"
                type="text"
                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                required=""
                @input="visitor.visitorPerpose = $event.target.value"
              >
            </div>
          </div>
        </div>
      </div>
      <hr class="block mt-4 mb-4">
      <span class="block mt-2 mb-8 font-bold text-lg">차량 정보</span>
      <div class="block ml-2 mr-2 grid grid-cols-4 gap-x-6">
        <div>
          <label
            for="vehicle-number"
            class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
          >차량 번호</label>
          <input
            id="vehicle-number"
            type="text"
            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
            required=""
            @input="visitor.visitorCarNumber = $event.target.value"
          >
        </div>
        <div>
          <label
            for="breadth"
            class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
          >차량 종류</label>
          <input
            id="breadth"
            type="text"
            name="breadth"
            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
            required=""
            @input="visitor.v_carkind = $event.target.value"
          >
        </div>
        <div>
          <label
            for="width"
            class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
          >차량 색상</label>
          <input
            id="width"
            type="text"
            name="width"
            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
            required=""
            @input="visitor.v_carcolor = $event.target.value"
          >
        </div>
        <div>
          <label
            for="length"
            class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
          >승용차 요일제</label>
          <select
            id="category"
            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
          >
            <option selected="">
              월요일
            </option>
            <option value="TV">
              화요일
            </option>
            <option value="TV">
              수요일
            </option>
            <option value="TV">
              목요일
            </option>
            <option value="TV">
              금요일
            </option>
          </select>
        </div>
      </div>
      <hr class="block mt-8 mb-8">
      <span class="block mb-8 font-bold text-lg">인솔자 정보</span>
      <div class="block ml-2 mr-2 mb-2 grid grid-cols-3 gap-x-6">
        <div>
          <label
            for="vehicle-number"
            class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
          >인솔자 성명</label>
          <input
            id="vehicle-number"
            type="text"
            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
            required=""
            @input="visitor.visitorCarNumber = $event.target.value"
          >
        </div>
        <div>
          <label
            for="breadth"
            class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
          >소속</label>
          <input
            id="breadth"
            type="text"
            name="breadth"
            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
            required=""
            @input="visitor.v_carkind = $event.target.value"
          >
        </div>
        <div>
          <label
            for="width"
            class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
          >연락처</label>
          <input
            id="width"
            type="text"
            name="width"
            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
            required=""
            @input="visitor.v_carcolor = $event.target.value"
          >
        </div>
      </div>
    </div>
    <div class="flex justify-end border-t">
      <div class="grid grid-cols-2 gap-x-6">
        <button
          type="submit"
          class=" inline-flex items-center px-5 py-2.5 mt-4 text-sm font-medium text-center text-white bg-primary-700 rounded-lg focus:ring-4 focus:ring-primary-200 dark:focus:ring-primary-900 hover:bg-primary-800"
        >
          취소
        </button>
        <button
          type="submit"
          class=" inline-flex items-center px-5 py-2.5 mt-4 text-sm font-medium text-center text-white bg-primary-700 rounded-lg focus:ring-4 focus:ring-primary-200 dark:focus:ring-primary-900 hover:bg-primary-800"
          @click="createVisitor"
        >
          등록
        </button>
      </div>
    </div>
  </form>
</template>

<script>
import axios from "axios"
export default {
  methods : {
    createVisitor(){
      let data = JSON.stringify({
        "visitorName": this.visitorName,
        "sosok": this.sosok,
        "phoneNumber": this.phoneNumber,
        "birthdate": this.birthdate,
        "visitType": ,
        "visitPlace": ,
        "visitPurpose": ,
        "visitStartTime": ,
        "visitEndTime": ,
        "firstRegistrationDatetime": ,
        "lastModificationDatetime": ,
        "carNumber": ,
        "carType": ,
        "carColor": ,
        "guideName": ,
        "guideSosok": ,
        "guidePhoneNumber":
      });
      
      let config = {
        method: 'post',
        maxBodyLength: Infinity,
        url: 'http://localhost:8080/visitor',
        headers: { 
          'Content-Type': 'application/json'
        },
        data : data
      };

      axios.request(config)
      .then((response) => {
        
      })
      .catch((error) => {
        console.log(error);
      });
    }
  }
}
</script>

<style scoped>
  label {
    @apply font-bold;
  }
</style>
