import {createRouter, createWebHashHistory} from 'vue-router';

const routes = [
  {
    path: '/',
    redirect: '/login',
    component: () => import('@/components/MainLayout.vue'),
    children: [
      {
        path: '/dashboard',
        name: 'MainDashboard',
        component: () => import('@/components/MainDashboard.vue'),
      },
      {
        path: '/visitor',
        name: 'VisitorList',
        component: () => import('@/components/visitor/VisitorList.vue'),
      },
      {
        path: '/visitor/register',
        name: 'VisitorRegister',
        component: () => import('@/components/visitor/VisitorRegister.vue'),
      }
    ],
  },

  {
    path: '/login',
    name: 'Login',
    component: () => import('@/components/MainLogin.vue'),
  },
];

const router = createRouter({
  // 4. Provide the history implementation to use.
  // We are using the hash history for simplicity here.
  history: createWebHashHistory(),

  // short for `routes: routes`
  routes,
});

export default router;
