import { createPinia, defineStore } from "pinia";

export const useVisitorRegisterStore = defineStore({
  state: () => ({
    isOpen: false,
  }),
  actions: {
    toggleVisitorRegister() {
      this.isOpen = !this.isOpen;
    },
  },
});

export const store = createPinia();

export default store;
